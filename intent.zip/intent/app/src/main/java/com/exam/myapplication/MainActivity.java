package com.exam.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button nxt = findViewById(R.id.btn_nxt);
        nxt.setOnClickListener(view -> {
            Intent newint = new Intent(this, MainActivity2.class);
            startActivity(newint);
        });
    }
}