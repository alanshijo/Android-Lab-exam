package com.exam.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Button nxt = findViewById(R.id.btn_nxt2);
        Button back = findViewById(R.id.btn_back);
        nxt.setOnClickListener(view -> {
            Intent newint = new Intent(this,MainActivity3.class);
            startActivity(newint);
        });
        back.setOnClickListener(view -> {
            Intent newint = new Intent(this,MainActivity.class);
            startActivity(newint);
        });
    }
}